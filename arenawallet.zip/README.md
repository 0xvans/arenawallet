# AVAX Wallet Bot

Panduan lengkap setup bot wallet Telegram untuk jaringan Avalanche.