# main.py - Telegram bot entry

from handlers import setup_handlers

if __name__ == '__main__':
    setup_handlers()